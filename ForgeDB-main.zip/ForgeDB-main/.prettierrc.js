module.exports = {
    parser: 'typescript',
    trailingComma: 'es5',
    tabWidth: 4,
    semi: false,
    printWidth: 200,
}
